<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle course registration
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];
    
    // Check how many courses the user is registered for
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM Registrations WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if ($result['total'] < 3) {
        $stmt = $conn->prepare("INSERT INTO Registrations (user_id, course_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $course_id);
        $stmt->execute();
    } else {
        $error = "You can only register for up to 3 courses.";
    }
}

// Handle course drop
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['drop_course_id'])) {
    $course_id = $_POST['drop_course_id'];
    $stmt = $conn->prepare("DELETE FROM Registrations WHERE user_id = ? AND course_id = ?");
    $stmt->bind_param("ii", $user_id, $course_id);
    $stmt->execute();
}

// Get registered courses
$registered_courses = $conn->prepare("
    SELECT Courses.course_id, Courses.course_name, Courses.course_description, Courses.start_date 
    FROM Courses 
    INNER JOIN Registrations ON Courses.course_id = Registrations.course_id 
    WHERE Registrations.user_id = ?");
$registered_courses->bind_param("i", $user_id);
$registered_courses->execute();
$registered_courses_result = $registered_courses->get_result();

// Get available courses
$available_courses = $conn->prepare("
    SELECT course_id, course_name 
    FROM Courses 
    WHERE course_id NOT IN (SELECT course_id FROM Registrations WHERE user_id = ?)");
$available_courses->bind_param("i", $user_id);
$available_courses->execute();
$available_courses_result = $available_courses->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - The University of Arizona Global Campus</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic CSS Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(120deg, #2980b9, #8e44ad);
            color: #333;
            padding: 20px;
        }

        .container {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
        }

        .container h1 {
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container h2 {
            font-size: 1.5em;
            color: #2980b9;
            margin-bottom: 15px;
        }

        .container ul {
            list-style-type: none;
            margin-bottom: 20px;
        }

        .container ul li {
            background-color: #f4f4f4;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .container ul li a {
            text-decoration: none;
            color: #2980b9;
        }

        .container form {
            display: inline;
        }

        .container form button {
            background-color: #8e44ad;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 5px 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .container form button:hover {
            background-color: #2980b9;
        }

        .container select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }

        .container button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #2980b9;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 1em;
        }

        .container button[type="submit"]:hover {
            background-color: #8e44ad;
        }

        .container p {
            color: red;
            font-size: 0.9em;
        }

        .header {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 1.5em;
            font-weight: bold;
            color: #fff;
        }

        .footer {
            position: absolute;
            bottom: 20px;
            font-size: 0.9em;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="header">The University of Arizona Global Campus</div>
    <div class="container">
        <h1>Dashboard</h1>

        <h2>Registered Courses</h2>
        <ul>
            <?php while ($row = $registered_courses_result->fetch_assoc()): ?>
                <li>
                    <a href="course_details.php?course_id=<?= $row['course_id'] ?>">
                        <?= $row['course_name'] ?>
                    </a>
                    <form method="POST">
                        <input type="hidden" name="drop_course_id" value="<?= $row['course_id'] ?>">
                        <button type="submit">Drop</button>
                    </form>
                </li>
            <?php endwhile; ?>
        </ul>

        <h2>Available Courses</h2>
        <form method="POST">
            <select name="course_id">
                <?php while ($row = $available_courses_result->fetch_assoc()): ?>
                    <option value="<?= $row['course_id'] ?>"><?= $row['course_name'] ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit">Register</button>
        </form>
        <?php if (isset($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
    <div class="footer">&copy; 2024 The University of Arizona Global Campus</div>
</body>
</html>
