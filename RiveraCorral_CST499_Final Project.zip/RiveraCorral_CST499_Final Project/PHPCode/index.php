<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to The University of Arizona Global Campus</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic CSS Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(120deg, #2980b9, #8e44ad);
            color: #333;
        }

        .container {
            text-align: center;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .container h1 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 20px;
        }

        .container p {
            font-size: 1.2em;
            margin-bottom: 20px;
        }

        .container a {
            text-decoration: none;
            color: #fff;
            background-color: #2980b9;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .container a:hover {
            background-color: #8e44ad;
        }

        .header {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 1.5em;
            font-weight: bold;
            color: #fff;
        }

        .footer {
            position: absolute;
            bottom: 20px;
            font-size: 0.9em;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="header">The University of Arizona Global Campus</div>
    <div class="container">
        <h1>Welcome to Our Website</h1>
        <p>Please <a href="login.php">Login</a> or <a href="register.php">Register</a></p>
    </div>
    <div class="footer">&copy; 2024 The University of Arizona Global Campus</div>
</body>
</html>
