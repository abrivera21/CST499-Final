<?php
include('db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $hashed_password, $email);

    if ($stmt->execute()) {
        header("Location: login.php"); 
        exit();
    } else {
        $error = "Failed to register. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - The University of Arizona Global Campus</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Basic CSS Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(120deg, #2980b9, #8e44ad);
            color: #333;
        }

        .container {
            text-align: center;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .container h1 {
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
        }

        .container form div {
            margin-bottom: 15px;
            text-align: left;
        }

        .container label {
            font-size: 1em;
            color: #333;
        }

        .container input[type="text"], 
        .container input[type="password"], 
        .container input[type="email"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 5px;
        }

        .container button {
            width: 100%;
            padding: 10px;
            background-color: #2980b9;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 1em;
        }

        .container button:hover {
            background-color: #8e44ad;
        }

        .container p {
            color: red;
            font-size: 0.9em;
            margin-top: 10px;
        }

        .header {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 1.5em;
            font-weight: bold;
            color: #fff;
        }

        .footer {
            position: absolute;
            bottom: 20px;
            font-size: 0.9em;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="header">The University of Arizona Global Campus</div>
    <div class="container">
        <h1>Register</h1>
        <form method="POST" action="">
            <div>
                <label for="username">Username:</label>
                <input type="text" name="username" required>
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" name="password" required>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" name="email" required>
            </div>
            <div>
                <button type="submit">Register</button>
            </div>
        </form>
        <?php if (isset($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
    <div class="footer">&copy; 2024 The University of Arizona Global Campus</div>
</body>
</html>
